package Enums;

public enum AuthType {
    SUCCESS,
    INVALID_CREDENTIALS,
    DATABASE_ERROR,
    FAILED
}