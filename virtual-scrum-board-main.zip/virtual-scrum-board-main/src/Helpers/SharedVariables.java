package Helpers;

public class SharedVariables {
    public static String loggedUser;
}
