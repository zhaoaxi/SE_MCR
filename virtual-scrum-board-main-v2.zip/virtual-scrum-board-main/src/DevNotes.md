# Development Notes

## ToDo List

- **Main Screen**
  - **Search Functionality**
    - Status: Done
  - **Account Btn**
    - Status: Done
    
  **Progress:** Finished

    ---

- **Project Screen**
  - **Load Tickets**
    - Status: Done
  - **Assign Btn**
    - Status: Done
  - **Load Project ID**
    - Status: Done
  - **Add new ticket**
    - Status: Done
  - **Update ticket**
    - Status: Done
  - **Link ticket**
    - Status: Done
  - **Open Secured Ticket**
    - Status: Done
  - **Search Functionality**
    - Status: Done
  - **Filters**
    - Status: Done
  - **Report Btn**
    - Status: Done

  **Progress:** Finished

    ---

- **Account Screen**
  - **UI Design**
    - Status: Done
  - **Populate Account Info**
    - Status: Done
  - **Update Account Info**
    - Status: Done
  - **Delete Account**
    - Status: Done

  **Progress:** Finished

    ---

- **General**
  - **Password Encryption**
    - Status: Done

  **Progress:** Finished

