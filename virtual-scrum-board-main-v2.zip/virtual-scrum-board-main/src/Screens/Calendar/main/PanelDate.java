package Screens.Calendar.main;

import java.awt.Component;
import java.util.Calendar;
import java.util.Date;

public class PanelDate extends javax.swing.JLayeredPane {

    private int month;
    private int year;
    private CalendarCustom cal;

    public PanelDate(int month, int year, CalendarCustom cal) {
        initComponents();
        this.month = month;
        this.year = year;
        this.cal = cal;
        init();
    }

    private void init() {
        mon.asTitle();
        tue.asTitle();
        wed.asTitle();
        thu.asTitle();
        fri.asTitle();
        sat.asTitle();
        sun.asTitle();
        setDate();
    }

    private void setDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month - 1);  //  month jan as 0 so start from 0
        calendar.set(Calendar.DATE, 1);
        int startDay = calendar.get(Calendar.DAY_OF_WEEK) - 1;  //  get day of week -1 to index
        calendar.add(Calendar.DATE, -startDay);
        ToDay toDay = getToDay();
        for (Component com : getComponents()) {
            Cell cell = (Cell) com;
            if (!cell.isTitle()) {
                cell.setText(calendar.get(Calendar.DATE) + "");
                cell.setDate(calendar.getTime());
                cell.currentMonth(calendar.get(Calendar.MONTH) == month - 1);
                if (toDay.isToDay(new ToDay(calendar.get(Calendar.DATE), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.YEAR)))) {
                    cell.setAsToDay();
                }
                calendar.add(Calendar.DATE, 1); //  up 1 day
            }
        }
    }

    private ToDay getToDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        return new ToDay(calendar.get(Calendar.DATE), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.YEAR));
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sun = new Screens.Calendar.main.Cell();
        mon = new Screens.Calendar.main.Cell();
        tue = new Screens.Calendar.main.Cell();
        wed = new Screens.Calendar.main.Cell();
        thu = new Screens.Calendar.main.Cell();
        fri = new Screens.Calendar.main.Cell();
        sat = new Screens.Calendar.main.Cell();
        cell1 = new Screens.Calendar.main.Cell();
        cell9 = new Screens.Calendar.main.Cell();
        cell10 = new Screens.Calendar.main.Cell();
        cell11 = new Screens.Calendar.main.Cell();
        cell12 = new Screens.Calendar.main.Cell();
        cell13 = new Screens.Calendar.main.Cell();
        cell14 = new Screens.Calendar.main.Cell();
        cell15 = new Screens.Calendar.main.Cell();
        cell16 = new Screens.Calendar.main.Cell();
        cell17 = new Screens.Calendar.main.Cell();
        cell18 = new Screens.Calendar.main.Cell();
        cell19 = new Screens.Calendar.main.Cell();
        cell20 = new Screens.Calendar.main.Cell();
        cell21 = new Screens.Calendar.main.Cell();
        cell22 = new Screens.Calendar.main.Cell();
        cell23 = new Screens.Calendar.main.Cell();
        cell24 = new Screens.Calendar.main.Cell();
        cell25 = new Screens.Calendar.main.Cell();
        cell26 = new Screens.Calendar.main.Cell();
        cell27 = new Screens.Calendar.main.Cell();
        cell28 = new Screens.Calendar.main.Cell();
        cell29 = new Screens.Calendar.main.Cell();
        cell30 = new Screens.Calendar.main.Cell();
        cell31 = new Screens.Calendar.main.Cell();
        cell32 = new Screens.Calendar.main.Cell();
        cell33 = new Screens.Calendar.main.Cell();
        cell34 = new Screens.Calendar.main.Cell();
        cell35 = new Screens.Calendar.main.Cell();
        cell36 = new Screens.Calendar.main.Cell();
        cell37 = new Screens.Calendar.main.Cell();
        cell38 = new Screens.Calendar.main.Cell();
        cell39 = new Screens.Calendar.main.Cell();
        cell40 = new Screens.Calendar.main.Cell();
        cell41 = new Screens.Calendar.main.Cell();
        cell42 = new Screens.Calendar.main.Cell();
        cell43 = new Screens.Calendar.main.Cell();
        cell44 = new Screens.Calendar.main.Cell();
        cell45 = new Screens.Calendar.main.Cell();
        cell46 = new Screens.Calendar.main.Cell();
        cell47 = new Screens.Calendar.main.Cell();
        cell48 = new Screens.Calendar.main.Cell();
        cell49 = new Screens.Calendar.main.Cell();

        setLayout(new java.awt.GridLayout(7, 7));

        sun.setForeground(new java.awt.Color(255, 51, 51));
        sun.setText("Sun");
        sun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sunActionPerformed(evt);
            }
        });
        add(sun);

        mon.setText("Mon");
        add(mon);

        tue.setText("Tue");
        tue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tueActionPerformed(evt);
            }
        });
        add(tue);

        wed.setText("Wed");
        add(wed);

        thu.setText("Thu");
        add(thu);

        fri.setText("Fri");
        add(fri);

        sat.setText("Sat");
        add(sat);

        cell1.setText("cell1");
        add(cell1);

        cell9.setText("cell9");
        add(cell9);

        cell10.setText("cell10");
        add(cell10);

        cell11.setText("cell11");
        add(cell11);

        cell12.setText("cell12");
        add(cell12);

        cell13.setText("cell13");
        add(cell13);

        cell14.setText("cell14");
        add(cell14);

        cell15.setText("cell15");
        add(cell15);

        cell16.setText("cell16");
        add(cell16);

        cell17.setText("cell17");
        add(cell17);

        cell18.setText("cell18");
        add(cell18);

        cell19.setText("cell19");
        add(cell19);

        cell20.setText("cell20");
        add(cell20);

        cell21.setText("cell21");
        add(cell21);

        cell22.setText("cell22");
        add(cell22);

        cell23.setText("cell23");
        add(cell23);

        cell24.setText("cell24");
        add(cell24);

        cell25.setText("cell25");
        add(cell25);

        cell26.setText("cell26");
        add(cell26);

        cell27.setText("cell27");
        add(cell27);

        cell28.setText("cell28");
        add(cell28);

        cell29.setText("cell29");
        add(cell29);

        cell30.setText("cell30");
        add(cell30);

        cell31.setText("cell31");
        add(cell31);

        cell32.setText("cell32");
        add(cell32);

        cell33.setText("cell33");
        add(cell33);

        cell34.setText("cell34");
        add(cell34);

        cell35.setText("cell35");
        add(cell35);

        cell36.setText("cell36");
        add(cell36);

        cell37.setText("cell37");
        add(cell37);

        cell38.setText("cell38");
        add(cell38);

        cell39.setText("cell39");
        add(cell39);

        cell40.setText("cell40");
        add(cell40);

        cell41.setText("cell41");
        add(cell41);

        cell42.setText("cell42");
        add(cell42);

        cell43.setText("cell43");
        add(cell43);

        cell44.setText("cell44");
        add(cell44);

        cell45.setText("cell45");
        add(cell45);

        cell46.setText("cell46");
        add(cell46);

        cell47.setText("cell47");
        add(cell47);

        cell48.setText("cell48");
        add(cell48);

        cell49.setText("cell49");
        add(cell49);
    }// </editor-fold>//GEN-END:initComponents

    private void sunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sunActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sunActionPerformed

    private void tueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tueActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Screens.Calendar.main.Cell cell1;
    private Screens.Calendar.main.Cell cell10;
    private Screens.Calendar.main.Cell cell11;
    private Screens.Calendar.main.Cell cell12;
    private Screens.Calendar.main.Cell cell13;
    private Screens.Calendar.main.Cell cell14;
    private Screens.Calendar.main.Cell cell15;
    private Screens.Calendar.main.Cell cell16;
    private Screens.Calendar.main.Cell cell17;
    private Screens.Calendar.main.Cell cell18;
    private Screens.Calendar.main.Cell cell19;
    private Screens.Calendar.main.Cell cell20;
    private Screens.Calendar.main.Cell cell21;
    private Screens.Calendar.main.Cell cell22;
    private Screens.Calendar.main.Cell cell23;
    private Screens.Calendar.main.Cell cell24;
    private Screens.Calendar.main.Cell cell25;
    private Screens.Calendar.main.Cell cell26;
    private Screens.Calendar.main.Cell cell27;
    private Screens.Calendar.main.Cell cell28;
    private Screens.Calendar.main.Cell cell29;
    private Screens.Calendar.main.Cell cell30;
    private Screens.Calendar.main.Cell cell31;
    private Screens.Calendar.main.Cell cell32;
    private Screens.Calendar.main.Cell cell33;
    private Screens.Calendar.main.Cell cell34;
    private Screens.Calendar.main.Cell cell35;
    private Screens.Calendar.main.Cell cell36;
    private Screens.Calendar.main.Cell cell37;
    private Screens.Calendar.main.Cell cell38;
    private Screens.Calendar.main.Cell cell39;
    private Screens.Calendar.main.Cell cell40;
    private Screens.Calendar.main.Cell cell41;
    private Screens.Calendar.main.Cell cell42;
    private Screens.Calendar.main.Cell cell43;
    private Screens.Calendar.main.Cell cell44;
    private Screens.Calendar.main.Cell cell45;
    private Screens.Calendar.main.Cell cell46;
    private Screens.Calendar.main.Cell cell47;
    private Screens.Calendar.main.Cell cell48;
    private Screens.Calendar.main.Cell cell49;
    private Screens.Calendar.main.Cell cell9;
    private Screens.Calendar.main.Cell fri;
    private Screens.Calendar.main.Cell mon;
    private Screens.Calendar.main.Cell sat;
    private Screens.Calendar.main.Cell sun;
    private Screens.Calendar.main.Cell thu;
    private Screens.Calendar.main.Cell tue;
    private Screens.Calendar.main.Cell wed;
    // End of variables declaration//GEN-END:variables
}
