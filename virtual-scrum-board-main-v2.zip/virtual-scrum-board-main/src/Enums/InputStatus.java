package Enums;

public enum InputStatus {
    REGULAR,
    WARNING,
    SUCCESS,
}
