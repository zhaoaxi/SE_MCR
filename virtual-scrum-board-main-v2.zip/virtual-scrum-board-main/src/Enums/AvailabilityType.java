package Enums;

public enum AvailabilityType {
    AVAILABLE,
    UNAVAILABLE,
    DATABASE_ERROR
}
