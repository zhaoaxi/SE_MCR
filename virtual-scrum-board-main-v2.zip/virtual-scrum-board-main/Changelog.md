# Changelog

## v1.0.0 (Initial Version)
- Initial release of the application.

## v1.0.1
- Modified version of v1.0.0.
- Changed `DevNotes.json` file to `DevNotes.md`.
- Changed Jasper report path to relative path.
- Hid report's column names.
- Added `Changelog.md` file.
- Added `README.md` file.
- Added `LogoBanner.svg`.

