/**
 * Copyright (C) 2014 - 2021 DLSC Software & Consulting GmbH (dlsc.com)
 *
 * This file is part of FlexGanttFX.
 */
package com.calendarfx.demo;

import fxsampler.FXSampler;

public class CalendarFXSampler {

    public static void main(String[] args) {
        FXSampler.main(args);
    }
}
