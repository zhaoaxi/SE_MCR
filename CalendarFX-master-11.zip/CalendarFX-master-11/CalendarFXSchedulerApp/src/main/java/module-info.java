module com.calendarfx.scheduler {
    requires transitive javafx.graphics;
    requires fr.brouillard.oss.cssfx;
    requires javafx.controls;
    requires com.calendarfx.view;

    exports com.calendarfx.scheduler;
}