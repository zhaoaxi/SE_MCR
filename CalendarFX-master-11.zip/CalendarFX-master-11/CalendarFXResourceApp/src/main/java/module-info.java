module com.calendarfx.resource.app {
    requires transitive javafx.graphics;

    requires javafx.controls;
    requires com.calendarfx.view;

    exports com.calendarfx.resource.app;
}